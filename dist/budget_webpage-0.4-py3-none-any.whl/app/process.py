
"""
The purpose of this class is to handle some data processing and calculating 
that I won't want to include in route or other part of the code.
"""

class process():

    def sum_amouts(transaction, budget, type):
        
        return 0
